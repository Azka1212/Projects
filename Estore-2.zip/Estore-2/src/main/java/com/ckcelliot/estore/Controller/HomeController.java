package com.ckcelliot.estore.Controller;

import com.ckcelliot.estore.DTO.ProductDTO;
import com.ckcelliot.estore.Entity.Product;
import com.ckcelliot.estore.Entity.User;
import com.ckcelliot.estore.Service.ProductCategoryService;
import com.ckcelliot.estore.Service.ProductService;
import com.ckcelliot.estore.Service.Impl.CartService;
import com.ckcelliot.estore.Service.Impl.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class HomeController {

    ProductCategoryService productCategoryService;
    ProductService productService;
    @Autowired
    UserService userService;
    @Autowired
    CartService cartService;

    public HomeController(ProductCategoryService productCategoryService, ProductService productService) {
        this.productCategoryService = productCategoryService;
        this.productService = productService;
    }

    @GetMapping({"/", "/home"})
    public String index(Model model) {
    	User user = userService.getUserDetails();
    	if(user!=null)
    	{
    		model.addAttribute("cartCount",cartService.getAllCartItemByUserId(user.getId()).size());      
    	}
        return "index";
    }

    @GetMapping("/shop")
    public String shop(Model model) { 
    	User user = userService.getUserDetails();
    	int cartCount = 0;
    	if(user!=null)
    	{
    		cartCount = cartService.getAllCartItemByUserId(user.getId()).size();    
    	}
		model.addAttribute("cartCount",cartCount); 
    	model.addAttribute("categories", productCategoryService.getAllCategory());
        model.addAttribute("products", productService.getAllProduct());
        return "shop";
    }

    @GetMapping({"/shop/category/{id}"})
    public String shopByCategory(@PathVariable int id, Model model) {
    	User user = userService.getUserDetails();
    	if(user!=null)
    	{
    		model.addAttribute("cartCount",cartService.getAllCartItemByUserId(user.getId()).size());      
    	}
        model.addAttribute("categories", productCategoryService.getAllCategory());
        model.addAttribute("products", productService.getAllProductsByCategoryId(id));
        return "shop";
    }

    @GetMapping({"/shop/viewproduct/{id}"})
    public String viewProduct(Model model, @PathVariable int id) {
    	User user = userService.getUserDetails();
    	if(user!=null)
    	{
    		model.addAttribute("cartCount",cartService.getAllCartItemByUserId(user.getId()).size());      
    	}
        model.addAttribute("product", productService.getProductById(id).get());
        return "viewProducts";
    }


}