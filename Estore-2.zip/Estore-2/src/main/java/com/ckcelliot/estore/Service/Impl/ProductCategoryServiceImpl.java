package com.ckcelliot.estore.Service.Impl;

import com.ckcelliot.estore.Entity.ProductCategory;
import com.ckcelliot.estore.Repository.ProductCategoryRepository;
import com.ckcelliot.estore.Service.ProductCategoryService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductCategoryServiceImpl implements ProductCategoryService {
    private ProductCategoryRepository productCategoryRepository;

    public ProductCategoryServiceImpl(ProductCategoryRepository productCategoryRepository) {
        this.productCategoryRepository = productCategoryRepository;
    }


    @Override
    public List<ProductCategory> getAllCategory() {
        return productCategoryRepository.findAll();
    }

    @Override
    public ProductCategory addCategory(ProductCategory productCategory) {
        return productCategoryRepository.save(productCategory);
    }

    @Override
    public void deleteCategoryById(int id) {
        productCategoryRepository.deleteById(id);
    }


    @Override
    public Optional<ProductCategory> getCategoryById(int id) {
        return productCategoryRepository.findById(id);
    }


}

