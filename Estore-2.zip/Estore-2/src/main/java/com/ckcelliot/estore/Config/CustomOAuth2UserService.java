//package com.ckcelliot.estore.Config;
//
//import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
//import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
//import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
//import org.springframework.security.oauth2.core.user.OAuth2User;
//import org.springframework.security.oauth2.core.user.OAuth2UserAuthority;
//import org.springframework.stereotype.Service;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Set;
//
//@Service
//public class CustomOAuth2UserService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {
//
//    private CustomOAuth2UserService customOAuth2UserService;
//
//    public CustomOAuth2UserService(CustomOAuth2UserService customOAuth2UserService) {
//        this.customOAuth2UserService = customOAuth2UserService;
//    }
//
//    public CustomOAuth2UserService() {
//    }
//
//    @Override
//    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
//        // Load user data from OAuth2 provider (e.g., Gmail)
//        // This method should be implemented based on the OAuth2 provider's API
//
//        // Dummy implementation
//        Map<String, Object> attributes = new HashMap<>();
//        attributes.put("email", "user@example.com"); // Example attribute
//
//        // Create an OAuth2UserAuthority to represent the user's authority
//        OAuth2UserAuthority authority = new OAuth2UserAuthority(attributes);
//        Set<OAuth2UserAuthority> authorities = Set.of(authority);
//
//        // Return OAuth2User instance with user details
//        return new OAuth2User() {
//            @Override
//            public Map<String, Object> getAttributes() {
//                return attributes;
//            }
//
//            @Override
//            public Set<OAuth2UserAuthority> getAuthorities() {
//                return authorities;
//            }
//
//            @Override
//            public String getName() {
//                return (String) attributes.get("email");
//            }
//        };
//    }
//}
