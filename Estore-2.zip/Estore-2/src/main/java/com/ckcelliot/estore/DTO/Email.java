package com.ckcelliot.estore.DTO;

import org.springframework.beans.factory.annotation.Value;

public class Email {
	private String subject;
	private String emailTo;
	@Value("${spring.mail.username}")
	private String emailForm;
	private String emailBody;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEmailTo() {
		return emailTo;
	}

	public void setEmailTo(String emailTo) {
		this.emailTo = emailTo;
	}

	public String getEmailBody() {
		return emailBody;
	}

	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}

	public String getEmailForm() {
		return emailForm;
	}

	public void setEmailForm(String emailForm) {
		this.emailForm = emailForm;
	}

}
