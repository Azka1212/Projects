package com.ckcelliot.estore.Service.Impl;

import com.ckcelliot.estore.Entity.User;
import com.ckcelliot.estore.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

	@Autowired
	private UserRepository repo;

	public void processOAuthPostLogin(String username) {
		Optional<User> existUser = repo.findUserByEmail(username);

		if (existUser == null) {
			User newUser = new User();
			newUser.setFirstName(username);
			repo.save(newUser);
		}

	}

	public User getUserDetails() {
		User user = null;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null) {
			String email = authentication.getName();
			Optional<User> optionalUser = this.repo.findUserByEmail(email);
			if (optionalUser.isPresent()) {
				user = optionalUser.get();
			}
		}
		return user;
	}
}