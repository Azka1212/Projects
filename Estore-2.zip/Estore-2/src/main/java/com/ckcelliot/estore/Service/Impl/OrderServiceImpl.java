package com.ckcelliot.estore.Service.Impl;

import java.math.BigDecimal;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ckcelliot.estore.Entity.Address;
import com.ckcelliot.estore.Entity.Order;
import com.ckcelliot.estore.Entity.OrderItem;
import com.ckcelliot.estore.Repository.OrderRepository;
import com.ckcelliot.estore.Service.OrderService;
import com.ckcelliot.estore.util.Constants;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;

//
//    private OrderRepository orderRepository;
//    private PaymentRepository paymentRepository;
//
//    public OrderServiceImpl(OrderRepository orderRepository, PaymentRepository paymentRepository) {
//        this.orderRepository = orderRepository;
//        this.paymentRepository = paymentRepository;
//    }
//
//    @Override
//    @Transactional // Rollback
//    public OrderResponse placeOrder(OrderRequest orderRequest) {
//
//        Order order = orderRequest.getOrder();
//        order.setStatus("INPROGRESS");
//        order.setOrderTrackingNumber(UUID.randomUUID().toString().replace("-", ""));
//        orderRepository.save(order);
//
//        Payment payment = orderRequest.getPayment();
//
//        if(!payment.getType().equals("DEBIT")){
//            throw new PaymentException("Payment card type do not support");
//        }
//
//        payment.setOrderId(order.getId());
//        paymentRepository.save(payment);
//
//        OrderResponse orderResponse = new OrderResponse();
//        orderResponse.setOrderTackingNumber(order.getOrderTrackingNumber());
//        orderResponse.setStatus(order.getStatus());
//        orderResponse.setMessage("SUCCESS");
//        return orderResponse;
//    }

	@Override
	public String getTrackingId() {
		String trackingId = "";
		trackingId = UUID.randomUUID().toString().replace("-", "");
		return trackingId;
	}

	@Override
	public void save(Order order) {
		this.orderRepository.save(order);
	}
}
