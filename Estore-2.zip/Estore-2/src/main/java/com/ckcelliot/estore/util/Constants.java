package com.ckcelliot.estore.util;

public class Constants {
    public static final String ROLE_ADMIN = "ADMIN";
    public static final String ROLE_NORMAL = "USER";
    
    public static final long SHIPPING_CHARGES = 1000;
    public static final String ORDER_STATUS_PENDING = "pending";
    
    public static final String ORDER_STATUS_INPROGRESS = "inprogress";
    public static final String ORDER_STATUS_SUCCESS = "success";
    
    public static final String CURRENCY_USD = "USD";
    
    public static final String ONLINE_ORDER_DESCRIPTION = "Online Order";
    
    public static final String ORDER_CONFIRMATION_EMAIL = "Order Confirmation Email";
   
}
