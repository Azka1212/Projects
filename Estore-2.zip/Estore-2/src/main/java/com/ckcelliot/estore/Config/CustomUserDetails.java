//package com.ckcelliot.estore.Config;
//
//import com.ckcelliot.estore.Entity.User;
//import org.springframework.security.core.GrantedAuthority;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;
//import org.springframework.security.core.userdetails.UserDetails;
//
//import java.util.Collection;
//import java.util.HashSet;
//import java.util.Set;
//
//public class CustomUserDetails implements UserDetails {
//
//    private final User user;
//
//    public CustomUserDetails(User user) {
//        this.user = user;
//    }
//
//    @Override
//    public Collection<? extends GrantedAuthority> getAuthorities() {
//        Set<GrantedAuthority> authorities = new HashSet<>();
//        user.getRoles().forEach(role -> authorities.add(new SimpleGrantedAuthority(role.getName())));
//        return authorities;
//    }
//
//    @Override
//    public String getPassword() {
//        return user.getPassword();
//    }
//
//    @Override
//    public String getUsername() {
//        return user.getEmail(); // Assuming email is the username
//    }
//
//    // Implement other UserDetails methods like isEnabled, isAccountNonExpired, etc.
//
//    @Override
//    public boolean isAccountNonExpired() {
//        return true; // Implement according to your logic
//    }
//
//    @Override
//    public boolean isAccountNonLocked() {
//        return true; // Implement according to your logic
//    }
//
//    @Override
//    public boolean isCredentialsNonExpired() {
//        return true; // Implement according to your logic
//    }
//
//    @Override
//    public boolean isEnabled() {
//        return true; // Implement according to your logic
//    }
//}
