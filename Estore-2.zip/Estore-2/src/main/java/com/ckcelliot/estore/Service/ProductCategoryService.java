package com.ckcelliot.estore.Service;

import com.ckcelliot.estore.Entity.ProductCategory;

import java.util.List;
import java.util.Optional;

public interface ProductCategoryService {
    List<ProductCategory> getAllCategory();

    ProductCategory addCategory(ProductCategory productCategory);

    public void deleteCategoryById(int id);

    Optional<ProductCategory> getCategoryById(int id);
}
