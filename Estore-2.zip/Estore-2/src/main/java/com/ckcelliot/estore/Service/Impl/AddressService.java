package com.ckcelliot.estore.Service.Impl;

import java.lang.StackWalker.Option;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ckcelliot.estore.Entity.Address;
import com.ckcelliot.estore.Repository.AddressRepository;

@Service
public class AddressService {
	@Autowired
	private AddressRepository addressRepository;

	public Address getAddressByUserId(long id) {
		Address address = null;
		Optional<Address> optional = this.addressRepository.findByUserId(id);
		if (optional.isPresent()) {
			address = optional.get();
		}
		return address;
	}

	public void saveOrUpdate(Address address) {
		this.addressRepository.save(address);
	}

}
