package com.ckcelliot.estore.Repository;

import com.ckcelliot.estore.Entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderRepository extends JpaRepository<Order, Long> {
}
