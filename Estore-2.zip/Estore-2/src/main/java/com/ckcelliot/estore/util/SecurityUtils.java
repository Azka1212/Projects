//package com.ckcelliot.estore.util;
//
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.core.userdetails.UserDetails;
//
//public class SecurityUtils {
//
//    public static UserDetails getCurrentUserDetails() {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
//            return (UserDetails) authentication.getPrincipal();
//        }
//        return null;
//    }
//
//    public static String getCurrentUsername() {
//        UserDetails userDetails = getCurrentUserDetails();
//        if (userDetails != null) {
//            return userDetails.getUsername();
//        }
//        return null;
//    }
//
//    public static String getCurrentUserRole() {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        if (authentication != null && !authentication.getAuthorities().isEmpty()) {
//            return authentication.getAuthorities().iterator().next().getAuthority();
//        }
//        return null;
//    }
//}
