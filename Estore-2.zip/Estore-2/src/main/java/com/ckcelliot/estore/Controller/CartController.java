package com.ckcelliot.estore.Controller;

import com.ckcelliot.estore.Entity.Cart;
import com.ckcelliot.estore.Entity.Product;
import com.ckcelliot.estore.Entity.User;
import com.ckcelliot.estore.Service.Impl.CartService;
import com.ckcelliot.estore.Service.Impl.UserService;
import com.ckcelliot.estore.util.Constants;
import com.ckcelliot.estore.Service.ProductService;

import org.apache.tomcat.util.bcel.classfile.Constant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
public class CartController {
	@Autowired
	private ProductService productService;

	@Autowired
	private CartService cartService;

	@Autowired
	private UserService userService;

	@GetMapping("/add-to-cart/{id}")
	public String addToCartHandler(@PathVariable("id") long id) {
		Cart cart = new Cart();
		cart.setProdcutId(id);
		User user = this.userService.getUserDetails();
		cart.setUserId(user.getId());
		cartService.addToCart(cart);
		return "redirect:/shop";
	}

	@GetMapping("/cart")
	public String cartView(Model model) {

		User user = userService.getUserDetails();
		String redirectUrl = "redirect:/";
		if (user != null) {
			Map<Integer, Product> productItems = new HashMap<>();
			BigDecimal totalPrice = BigDecimal.ZERO;
			List<Cart> cartItems = this.cartService.getAllCartItemByUserId(user.getId());
			model.addAttribute("cartCount", cartItems.size());
			if (cartItems != null && cartItems.size()>0) {
				for (Cart item : cartItems) {
					Optional<Product> optional = this.productService.getProductById(item.getProdcutId());
					if (optional.isPresent()) {
						Product product = optional.get();
						productItems.put(item.getId(), product);
						totalPrice = totalPrice.add(product.getPrice());
					}
				}
				redirectUrl = "/cart";
			}
			model.addAttribute("total", totalPrice);
			model.addAttribute("shippingCharge", Constants.SHIPPING_CHARGES);
			model.addAttribute("cartItems", productItems);
		}
		return redirectUrl;
	}

	@GetMapping("/cart/removeItem/{id}")
	public String deleteCartItem(@PathVariable("id") long id) {
		User user = this.userService.getUserDetails();
		if (user != null) {
			this.cartService.deleteById(id);
		}
		return "redirect:/cart";
	}

}
