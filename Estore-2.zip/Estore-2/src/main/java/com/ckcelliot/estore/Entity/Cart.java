package com.ckcelliot.estore.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "cart_items")
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "user_id")
    private long userId;

    @Column(name = "product_id")
    private long prodcutId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public long getProdcutId() {
        return prodcutId;
    }

    public void setProdcutId(long prodcutId) {
        this.prodcutId = prodcutId;
    }

    @Override
    public String toString() {
        return "Cart{" +
                "id=" + id +
                ", userId=" + userId +
                ", prodcutId=" + prodcutId +
                '}';
    }
}