package com.ckcelliot.estore.Repository;

import com.ckcelliot.estore.Entity.Address;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {
	
	Optional<Address> findByUserId(long userId);
}
