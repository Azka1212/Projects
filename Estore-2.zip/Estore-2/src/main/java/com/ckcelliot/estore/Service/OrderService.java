package com.ckcelliot.estore.Service;

import java.math.BigDecimal;
import java.util.Set;

import com.ckcelliot.estore.Entity.Address;
import com.ckcelliot.estore.Entity.Order;
import com.ckcelliot.estore.Entity.OrderItem;

public interface OrderService {
//    OrderResponse placeOrder(OrderRequest orderRequest);
	public String getTrackingId();
	
	public void save(Order order);
	
}
