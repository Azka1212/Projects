package com.ckcelliot.estore.Controller;

import com.ckcelliot.estore.Service.PaypalService;
import com.ckcelliot.estore.util.Constants;
import com.paypal.api.payments.Links;
import com.paypal.api.payments.Payment;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.RedirectView;

@Controller
@RequestMapping("/payment")
public class PaypalController {
    @Autowired
    private PaypalService paypalService;

    public static final String SUCCESS_URL = "/success";
    public static final String CANCEL_URL = "/cancel";
    
    @GetMapping("/process-payment/{amount}")
    public String paypal(@PathVariable("amount") Double amount,HttpServletRequest request){
        try {
            Payment payment = this.paypalService.createPayment(
                    amount, Constants.CURRENCY_USD, "paypal", "Online Order", Constants.ONLINE_ORDER_DESCRIPTION, request.getContextPath()+CANCEL_URL, request.getContextPath()+SUCCESS_URL);

            for (Links link : payment.getLinks()) {
                if (link.getRel().equals("approval_url")) {
                    return "redirect:" + link.getHref();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "redirect:/";
    }

    @GetMapping(value = SUCCESS_URL)
    public String paymentSuccess(@RequestParam("paymentId") String paymentId, @RequestParam("payerId") String payerId) {
        try {
            Payment payment = this.paypalService.executePayment(paymentId, payerId);
            if (payment.getState().equals("approved")) {
            	return "redirect:/order/order-completed";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "redirect:/order/order-completed";
    }


    @GetMapping(value = CANCEL_URL)
    public String paymentCanel() {
        return "redirect:/";
    }
}
