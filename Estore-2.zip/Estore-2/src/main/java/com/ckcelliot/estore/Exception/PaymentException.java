package com.ckcelliot.estore.Exception;

public class PaymentException extends RuntimeException {
    public PaymentException(String message){
        super(message);
    }
}
