package com.ckcelliot.estore.Service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.ckcelliot.estore.DTO.Email;
import com.ckcelliot.estore.Entity.Order;
import com.ckcelliot.estore.Entity.User;

@Service
public class EmailService {
	
	@Autowired
	private JavaMailSender mailSender;
	
	public void sendOrderConfirmationEmail(Email email) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setFrom(email.getEmailForm());
		message.setTo(email.getEmailTo());
		message.setSubject(email.getSubject());
		message.setText(email.getEmailBody());
		
		mailSender.send(message);
	}
}
