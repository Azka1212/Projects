package com.ckcelliot.estore.Controller;

import com.ckcelliot.estore.Entity.Role;
import com.ckcelliot.estore.Entity.User;
import com.ckcelliot.estore.Repository.RoleRepository;
import com.ckcelliot.estore.Repository.UserRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Controller
public class LoginController {
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@GetMapping("/login")
	public String login() {
		return "login";
	}

	@GetMapping("/register")
	public String registerGet() {
		return "register";
	}
	@GetMapping("/oauth2/authorization/google")
	public String redirectToGoogle() {
	    return "redirect:/register/oauth/gmail";
	}

	@PostMapping("/register")
	public String registerPost(@ModelAttribute("user") User user, HttpServletRequest request) throws ServletException {
		String password = bCryptPasswordEncoder.encode(user.getPassword());
		user.setPassword(password);
		List<Role> roles = new ArrayList<>();
		roles.add(roleRepository.findById(2).get());
		user.setRoles(roles);
		userRepository.save(user);
		request.login(user.getEmail(), password);
		return "redirect:/";
	}

	@GetMapping("/register/login-gmail")
	public String redirectGoogle() {
	    return "redirect:/register/oauth/gmail";
	}

}
