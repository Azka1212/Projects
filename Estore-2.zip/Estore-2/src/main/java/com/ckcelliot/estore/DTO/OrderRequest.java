package com.ckcelliot.estore.DTO;

import com.ckcelliot.estore.Entity.Order;
import com.ckcelliot.estore.Entity.Payment;
import jakarta.persistence.criteria.From;
import lombok.Data;

// From Client to Server
@Data
public class OrderRequest {
    private Order order;
    private Payment payment;
}
